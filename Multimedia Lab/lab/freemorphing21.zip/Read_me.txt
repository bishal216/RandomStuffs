Free Morphing
Version 2.1 

Description.
Morphing is the process of transforming one image into another. Free Morphing creates a sequence of frames which are the transformation of the source image to target image, giving the appearance that the source image "becomes" the target. 
Images must be true color (24 bit) and have the same size. In the program you can create lines (the same number in Source and Target) which describe the transformation. You should create line objects in the same order on boths images. There are various viewing tools for preview morphing. 


Features: 

- You can specify the number of frames in sequence.
- You can create symmetric sequence.
- You can save resulting movies as animated GIF, AVI and so on.


Freeware.
Copyright (C) 2006 FilesGuard.
All rights reserved.
